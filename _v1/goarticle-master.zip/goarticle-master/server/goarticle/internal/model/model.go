package model

type Msg struct {
	Code int
	Message string
	Data interface{}
}

type Article struct {
	Title string	`文章标题`
	Body string		`文章内容`
}
