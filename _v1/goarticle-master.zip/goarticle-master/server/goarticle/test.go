package main

import (
	"fmt"
	"goarticle/internal/domain"
)

func main() {
	fmt.Println("on test")

	//metaweblog.Test()
	domain.Test()

	fmt.Println("done")

}
