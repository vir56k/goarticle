import React, { Component } from 'react';
import './Footer.css';
import service from './Service.js'


class Footer extends Component {

  constructor(props) {
    super(props);
  }

  componentDidMount() {

  }

  render() {
    return (
      <footer className="App-footer"></footer>
    );
  }
}

export default Footer;
